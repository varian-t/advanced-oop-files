using Avalonia.Controls;

namespace DataTemplateMVVM.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}