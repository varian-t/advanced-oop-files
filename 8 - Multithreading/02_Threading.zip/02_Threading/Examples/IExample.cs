namespace Threading.Examples;

interface IExample
{
    public string Name { get;}
    void Run();
}