﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace LiveChartTest.ViewModels;

public class ViewModelBase : ObservableObject
{
}
