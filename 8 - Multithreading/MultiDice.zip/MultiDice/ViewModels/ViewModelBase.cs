﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace MultiDice.ViewModels;

public class ViewModelBase : ObservableObject
{
}
