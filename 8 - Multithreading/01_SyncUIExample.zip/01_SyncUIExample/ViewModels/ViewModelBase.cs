﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SyncUIExample.ViewModels;

public class ViewModelBase : ObservableObject
{
}
