﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace DataTemplateMVVM.ViewModels;

public class ViewModelBase : ObservableObject
{
}
