using System;
using Avalonia.Controls;
using Avalonia.Interactivity;

namespace Polymorphism.Polymorphism;

public partial class MainWindow : Window
{
    public MainWindow() 
    {
        InitializeComponent();
        // RadioEllipse.Content = ShapeFacade.Shapes.Ellipse;
        // RadioRectangle.Content = ShapeFacade.Shapes.Rectangle;
        // RadioCircle.Content = ShapeFacade.Shapes.Circle;
        // RadioSquare.Content = ShapeFacade.Shapes.Square;
        
    }
}