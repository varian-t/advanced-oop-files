using Avalonia.Controls;

namespace MultiDice.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}