using Avalonia.Controls;

namespace SyncUIExample.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}