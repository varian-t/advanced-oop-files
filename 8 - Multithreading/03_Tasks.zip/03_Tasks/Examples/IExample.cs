namespace Tasks.Examples;

interface IExample
{
    public string Name { get;}
    void Run();
}