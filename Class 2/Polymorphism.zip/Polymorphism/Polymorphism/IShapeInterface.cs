namespace Polymorphism.Polymorphism;

public interface IShapeInterface
{
    double GetArea(); 

    double GetCircumference();
}