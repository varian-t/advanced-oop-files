namespace MultiDice.Models;

using MultiDice.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;

using Avalonia;
using Avalonia.Media.Imaging; 


public class DiceGame 
{
    private bool _isRunning = false;
    private MainWindowViewModel _viewModel;

    public DiceGame(MainWindowViewModel viewModel)
    {
        _viewModel = viewModel;
    }

    // TODO : Start rolling the dice
    public async Task Start()
    {
        throw new NotImplementedException();
    }

    // TODO : Stop rolling the dice
    public void Stop()
    {
        throw new NotImplementedException();
    }

    // TODO : Start a new DiceRolling Task that rolls 2 dice until either the User presses Stop or 
    // both dice show a 6. Continously Update the UI through the View Model.
    private Task DiceRolling()
    {
        throw new NotImplementedException();
    }

}